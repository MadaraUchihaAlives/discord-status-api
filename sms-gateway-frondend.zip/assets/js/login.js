document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const alertBox = document.getElementById("alertBox");
  alertBox.hidden = true;

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  const { response, data } = await window.XD_SMS.api("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password }),
    skipAuthRedirect: true
  });

  if (response.ok) {
    window.XD_SMS.setSession(data.token, data.user);
    window.location.href = "dashboard.html";
    return;
  }

  alertBox.hidden = false;
  alertBox.className = "alert alert-error";
  alertBox.textContent = data?.error || "Login failed";
});
