(function () {
  const storageKey = "xd_sms_theme";

  function getPreferredTheme() {
    const saved = localStorage.getItem(storageKey);
    if (saved === "light" || saved === "dark") return saved;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    document.querySelectorAll("[data-theme-icon]").forEach((el) => {
      el.textContent = theme === "dark" ? "☀" : "☾";
    });
  }

  window.XD_SMS = window.XD_SMS || {};
  window.XD_SMS.getTheme = getPreferredTheme;

  window.XD_SMS.setTheme = function (theme) {
    localStorage.setItem(storageKey, theme);
    applyTheme(theme);
  };

  window.XD_SMS.toggleTheme = function () {
    const next = getPreferredTheme() === "dark" ? "light" : "dark";
    window.XD_SMS.setTheme(next);
  };

  applyTheme(getPreferredTheme());

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("[data-theme-toggle]").forEach((btn) => {
      btn.addEventListener("click", window.XD_SMS.toggleTheme);
    });

    document.querySelectorAll("[data-mobile-menu]").forEach((btn) => {
      btn.addEventListener("click", () => {
        document.querySelector(".sidebar")?.classList.toggle("open");
      });
    });

    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener("click", (e) => {
        const target = document.querySelector(anchor.getAttribute("href"));
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: "smooth" });
        }
      });
    });
  });
})();
